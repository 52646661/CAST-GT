# CAST-GT implementation

Runnable PyTorch research implementation of a climate-adaptive spatio-temporal graph Transformer.

## Important
This ZIP contains implementation code, not the original datasets or verified manuscript results.
The synthetic run is only a smoke test. Do not report its metrics as research findings.
Use the actual datasets and final experiment protocol to produce valid results.

## Install
`pip install -r requirements.txt`

## Input CSV
Required columns: `region_id`, `date`, `yield`, climate columns (default:
`temperature precipitation humidity`), and optional static columns
(default: `soil_ph elevation`). Each row represents one region/time observation.

## Run synthetic smoke test
`python run_experiment.py --synthetic --epochs 2 --output outputs/smoke`

## Run your data
`python run_experiment.py --data data.csv --climate-cols temperature precipitation humidity --static-cols soil_ph elevation --window 12 --epochs 100 --seed 42 --output outputs/run42`

Run multiple seeds independently, then aggregate metrics from the output files.
Chronological splits and train-only scaling are used. The model includes temporal
Transformer encoding, graph attention, climate-conditioned fusion, and a Gaussian
predictive head trained with Gaussian NLL. Outputs include metrics, predictions,
training history, config, and model weights.

Custom metrics are utilities requiring reference data. PADE requires independent
field, simulation, expert, or decision-utility validation; it is not computed
from the synthetic smoke test.
