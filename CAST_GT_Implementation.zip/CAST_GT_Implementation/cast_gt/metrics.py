import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

def regression_metrics(y, p):
    y, p = np.asarray(y).ravel(), np.asarray(p).ravel()
    return {
        "RMSE": float(np.sqrt(mean_squared_error(y,p))),
        "MAE": float(mean_absolute_error(y,p)),
        "R2": float(r2_score(y,p)),
        "MAPE_percent": float(np.mean(np.abs((y-p)/np.maximum(np.abs(y),1e-8)))*100)
    }

def interval_metrics(y, lo, hi):
    y, lo, hi = map(lambda z: np.asarray(z).ravel(), (y,lo,hi))
    picp = np.mean((y >= lo) & (y <= hi))*100
    scale = max(np.ptp(y), 1e-8)
    pinaw = np.mean(hi-lo)/scale*100
    return {"PICP_percent": float(picp), "PINAW_percent": float(pinaw)}

def mcse(pred_sensitivity, reference_sensitivity):
    return float(np.mean(np.abs(np.asarray(pred_sensitivity)-np.asarray(reference_sensitivity))))

def cacs(attention, reference_importance):
    a, q = np.asarray(attention).ravel(), np.asarray(reference_importance).ravel()
    den = np.linalg.norm(a)*np.linalg.norm(q)
    return float(np.clip(a@q/den,0,1)) if den else float("nan")

def efs(original, perturbed, mean_prediction, eps=1e-8):
    original, perturbed = np.asarray(original), np.asarray(perturbed)
    return float(1-np.mean(np.abs(original-perturbed))/
                 (np.mean(np.abs(original-mean_prediction))+eps))

def pade(category_utilities):
    u=np.asarray(category_utilities,dtype=float)
    if np.any((u<0)|(u>1)): raise ValueError("Utilities must be normalized to [0,1]")
    return float(np.mean(u))
