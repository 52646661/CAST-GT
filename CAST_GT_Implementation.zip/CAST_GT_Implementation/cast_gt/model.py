import math
import torch
from torch import nn

class GraphAttention(nn.Module):
    def __init__(self, d, dropout=.1):
        super().__init__()
        self.q=nn.Linear(d,d,bias=False); self.k=nn.Linear(d,d,bias=False)
        self.v=nn.Linear(d,d,bias=False); self.o=nn.Linear(d,d)
        self.drop=nn.Dropout(dropout); self.norm=nn.LayerNorm(d)
    def forward(self,x,adj):
        q,k,v=self.q(x),self.k(x),self.v(x)
        s=q@k.transpose(-2,-1)/math.sqrt(x.shape[-1])
        s=s.masked_fill(~adj.bool().unsqueeze(0),-1e9)
        a=s.softmax(-1)
        return self.norm(x+self.o(self.drop(a)@v)),a

class CASTGT(nn.Module):
    # x [batch, regions, window, features], climate [batch, regions, window, climate_dim]
    def __init__(self, feature_dim, climate_dim, d=64, heads=4, layers=2, dropout=.1):
        super().__init__()
        self.embed=nn.Linear(feature_dim,d); self.clim=nn.Linear(climate_dim,d)
        enc=nn.TransformerEncoderLayer(d,heads,4*d,dropout,batch_first=True,
                                     norm_first=True,activation="gelu")
        self.temporal=nn.TransformerEncoder(enc,layers)
        self.graph=nn.ModuleList([GraphAttention(d,dropout) for _ in range(2)])
        self.climate_bias=nn.Sequential(nn.Linear(d,d),nn.Tanh())
        self.fuse=nn.Sequential(nn.Linear(3*d,d),nn.GELU(),nn.LayerNorm(d),nn.Dropout(dropout))
        self.mean=nn.Linear(d,1); self.logvar=nn.Linear(d,1)
    def forward(self,x,climate,adj):
        b,r,w,f=x.shape
        ht=self.temporal(self.embed(x).reshape(b*r,w,-1))[:,-1].reshape(b,r,-1)
        hs=self.embed(x[:,:,-1])
        attn=None
        for layer in self.graph: hs,attn=layer(hs,adj)
        hc=self.clim(climate[:,:,-1]); hc=hc+self.climate_bias(hc)
        h=self.fuse(torch.cat([ht,hs,hc],-1))
        return self.mean(h).squeeze(-1), self.logvar(h).squeeze(-1).clamp(-8,5), attn
