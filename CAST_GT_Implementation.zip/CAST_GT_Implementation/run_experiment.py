import argparse, json, random
from pathlib import Path
import numpy as np, pandas as pd, torch
from sklearn.preprocessing import StandardScaler
from cast_gt.model import CASTGT
from cast_gt.metrics import regression_metrics, interval_metrics

def synthetic(seed=42, regions=8, steps=80):
    rng=np.random.default_rng(seed); rows=[]
    for r in range(regions):
        t=np.arange(steps); temp=24+6*np.sin(t/9+r/3)+rng.normal(0,1,steps)
        rain=np.maximum(0,4+2*np.sin(t/7+r)+rng.normal(0,1,steps))
        hum=65+10*np.sin(t/11+r)+rng.normal(0,2,steps)
        y=2+.04*rain-.02*(temp-25)**2+.01*hum+rng.normal(0,.12,steps)
        for i in range(steps):
            rows.append([f"R{r:03}",pd.Timestamp("2015-01-01")+pd.DateOffset(months=i),
                         y[i],temp[i],rain[i],hum[i],6.3+r*.02,100+r*10])
    return pd.DataFrame(rows,columns=["region_id","date","yield","temperature","precipitation","humidity","soil_ph","elevation"])

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--data"); p.add_argument("--synthetic",action="store_true")
    p.add_argument("--target",default="yield"); p.add_argument("--region-col",default="region_id")
    p.add_argument("--date-col",default="date")
    p.add_argument("--climate-cols",nargs="+",default=["temperature","precipitation","humidity"])
    p.add_argument("--static-cols",nargs="*",default=["soil_ph","elevation"])
    p.add_argument("--window",type=int,default=12); p.add_argument("--epochs",type=int,default=50)
    p.add_argument("--seed",type=int,default=42); p.add_argument("--output",default="outputs/run")
    a=p.parse_args()
    if not a.synthetic and not a.data: p.error("Provide --data or --synthetic")
    random.seed(a.seed); np.random.seed(a.seed); torch.manual_seed(a.seed)
    out=Path(a.output); out.mkdir(parents=True,exist_ok=True)
    df=synthetic(a.seed) if a.synthetic else pd.read_csv(a.data)
    df[a.date_col]=pd.to_datetime(df[a.date_col]); df=df.sort_values(a.date_col)
    dates=np.array(sorted(df[a.date_col].unique()))
    ntr=int(.70*len(dates)); nva=int(.85*len(dates))
    trdates, vadates, tedates=dates[:ntr],dates[ntr:nva],dates[nva:]
    feats=a.climate_cols+a.static_cols
    med=df[df[a.date_col].isin(trdates)][feats].median()
    sx=StandardScaler().fit(df[df[a.date_col].isin(trdates)][feats].fillna(med))
    sy=StandardScaler().fit(df[df[a.date_col].isin(trdates)][[a.target]])
    df[feats]=sx.transform(df[feats].fillna(med)); df[a.target]=sy.transform(df[[a.target]])
    regions=sorted(df[a.region_col].unique())
    def samples(splitdates):
        part=df[df[a.date_col].isin(splitdates)]
        times=sorted(part[a.date_col].unique()); X=[]; C=[]; Y=[]
        for end in range(a.window,len(times)):
            hist=part[part[a.date_col].isin(times[end-a.window:end])]
            target=part[part[a.date_col]==times[end]].set_index(a.region_col)
            if any(len(hist[hist[a.region_col]==r])!=a.window or r not in target.index for r in regions): continue
            X.append(np.stack([hist[hist[a.region_col]==r][feats].to_numpy() for r in regions]))
            C.append(np.stack([hist[hist[a.region_col]==r][a.climate_cols].to_numpy() for r in regions]))
            Y.append(target.loc[regions,a.target].to_numpy())
        return tuple(np.asarray(v,dtype=np.float32) for v in (X,C,Y))
    train,val,test=map(samples,(trdates,vadates,tedates))
    if min(map(len,(train[0],val[0],test[0])))==0: raise ValueError("Not enough data per split/window.")
    # Train-only climate/static region affinity graph, top-k including self.
    means=df[df[a.date_col].isin(trdates)].groupby(a.region_col)[a.climate_cols].mean().reindex(regions).fillna(0).to_numpy()
    means=means/(np.linalg.norm(means,axis=1,keepdims=True)+1e-8)
    sim=means@means.T; adj=np.zeros_like(sim,dtype=bool)
    for i in range(len(regions)): adj[i,np.argsort(sim[i])[-min(8,len(regions)):]]=True
    adj|=adj.T
    device="cuda" if torch.cuda.is_available() else "cpu"
    model=CASTGT(len(feats),len(a.climate_cols)).to(device); A=torch.tensor(adj,device=device)
    opt=torch.optim.Adam(model.parameters(),lr=1e-3); best=float("inf"); state=None; wait=0
    history=[]
    for epoch in range(a.epochs):
        model.train(); losses=[]
        order=np.random.permutation(len(train[0]))
        for idx in order:
            x=torch.tensor(train[0][idx:idx+1],device=device); c=torch.tensor(train[1][idx:idx+1],device=device); y=torch.tensor(train[2][idx:idx+1],device=device)
            opt.zero_grad(); mu,lv,_=model(x,c,A)
            loss=.5*(lv+(y-mu)**2*torch.exp(-lv)).mean(); loss=loss.mean()
            loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1); opt.step(); losses.append(loss.item())
        model.eval()
        with torch.no_grad():
            mu,lv,_=model(torch.tensor(val[0],device=device),torch.tensor(val[1],device=device),A)
            vloss=.5*(lv+(torch.tensor(val[2],device=device)-mu)**2*torch.exp(-lv)).mean()
        history.append({"epoch":epoch+1,"train_nll":float(np.mean(losses)),"val_nll":float(vloss)})
        if vloss.item()<best: best=vloss.item(); state={k:v.cpu().clone() for k,v in model.state_dict().items()}; wait=0
        else:
            wait+=1
            if wait>=15: break
    model.load_state_dict(state); model.eval()
    with torch.no_grad():
        mu,lv,_=model(torch.tensor(test[0],device=device),torch.tensor(test[1],device=device),A)
    mu=mu.cpu().numpy(); sig=np.sqrt(np.exp(lv.cpu().numpy()))
    y=sy.inverse_transform(test[2].reshape(-1,1)).reshape(test[2].shape)
    pred=sy.inverse_transform(mu.reshape(-1,1)).reshape(mu.shape)
    lo=sy.inverse_transform((mu-1.96*sig).reshape(-1,1)).reshape(mu.shape)
    hi=sy.inverse_transform((mu+1.96*sig).reshape(-1,1)).reshape(mu.shape)
    metrics=regression_metrics(y,pred); metrics.update(interval_metrics(y,lo,hi))
    (out/"metrics.json").write_text(json.dumps(metrics,indent=2))
    pd.DataFrame(history).to_csv(out/"training_history.csv",index=False)
    pd.DataFrame({"y_true":y.ravel(),"y_pred":pred.ravel(),"lower_95":lo.ravel(),"upper_95":hi.ravel()}).to_csv(out/"test_predictions.csv",index=False)
    torch.save(model.state_dict(),out/"cast_gt.pt")
    (out/"config.json").write_text(json.dumps(vars(a),indent=2))
    print(json.dumps(metrics,indent=2))
if __name__=="__main__": main()
